package com.contoh.boxpvp;

import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.block.Block;
import org.bukkit.entity.AbstractArrow;
import org.bukkit.entity.Arrow;
import org.bukkit.entity.Player;
import org.bukkit.event.Event;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.entity.ProjectileHitEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.metadata.FixedMetadataValue;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.util.Vector;

import java.util.ArrayList;
import java.util.List;

public final class WebTrapAbility implements Listener {

    private static final String META = "boxpvp_web_trap";

    private final BoxPVPAbilities plugin;
    private final List<List<Block>> placedWebs = new ArrayList<>();

    public WebTrapAbility(BoxPVPAbilities plugin) {
        this.plugin = plugin;
    }

    @EventHandler
    public void onRightClick(PlayerInteractEvent event) {
        if (event.getAction() != Action.RIGHT_CLICK_AIR && event.getAction() != Action.RIGHT_CLICK_BLOCK) return;
        if (event.getHand() != EquipmentSlot.HAND) return;
        if (!plugin.getAbilityItems().isAbility(event.getItem(), AbilityItems.WEB_TRAP)) return;

        event.setUseItemInHand(Event.Result.DENY);
        event.setCancelled(true);

        Player player = event.getPlayer();
        if (!plugin.beginUse(player, AbilityItems.WEB_TRAP, "Web Trap", "web-trap", 30)) return;

        int extra = plugin.getConfig().getInt("web-trap.extra-arrows", 2);
        double spread = plugin.getConfig().getDouble("web-trap.arrow-spread", 0.18);

        Vector direction = player.getEyeLocation().getDirection();

        for (int i = 0; i <= extra; i++) {
            double yawOffset = 0;
            if (i > 0) {
                yawOffset = (i % 2 == 1 ? 1 : -1) * 12.0 * ((i + 1) / 2);
            }

            Vector velocity = direction.clone().rotateAroundY(Math.toRadians(yawOffset)).multiply(2.6);

            if (i > 0) {
                velocity.add(new Vector(
                        (Math.random() - 0.5) * spread,
                        (Math.random() - 0.5) * spread,
                        (Math.random() - 0.5) * spread));
            }

            Arrow arrow = player.launchProjectile(Arrow.class, velocity);
            arrow.setPickupStatus(AbstractArrow.PickupStatus.DISALLOWED);
            arrow.setMetadata(META, new FixedMetadataValue(plugin, true));
        }

        player.getWorld().playSound(player.getLocation(), Sound.ITEM_CROSSBOW_SHOOT, 1.0F, 1.0F);
        player.getWorld().spawnParticle(Particle.ENCHANTMENT_TABLE,
                player.getEyeLocation(), 20, 0.3, 0.3, 0.3, 1.0);
    }

    @EventHandler
    public void onArrowHit(ProjectileHitEvent event) {
        if (!(event.getEntity() instanceof Arrow arrow)) return;
        if (!arrow.hasMetadata(META)) return;

        arrow.removeMetadata(META, plugin);

        Location impact = arrow.getLocation();
        if (event.getHitEntity() != null) {
            impact = event.getHitEntity().getLocation();
        }

        createWebTrap(impact.getBlock().getLocation().add(0.5, 0.5, 0.5));
        arrow.remove();
    }

    private void createWebTrap(Location center) {
        int duration = plugin.getConfig().getInt("web-trap.web-duration", 8) * 20;
        Particle.DustOptions dust = ParticleUtil.dust(
                plugin.getConfig().getString("web-trap.colors", "240,240,240"));

        AbilityMusic.play(plugin, "web-trap", center, 24L + duration);

        new BukkitRunnable() {
            double radius = 3.0;

            @Override
            public void run() {
                radius -= 0.25;

                if (radius <= 0) {
                    placeWebs(center, duration);
                    cancel();
                    return;
                }

                ParticleUtil.circle(center, radius, 32, Particle.REDSTONE, dust);
                ParticleUtil.spiral(center, radius, 1.5, 24, Particle.CLOUD, null);
            }
        }.runTaskTimer(plugin, 0L, 2L);
    }

    private void placeWebs(Location center, int durationTicks) {
        List<Block> changed = new ArrayList<>();

        for (int x = -1; x <= 1; x++) {
            for (int y = -1; y <= 1; y++) {
                for (int z = -1; z <= 1; z++) {
                    Block block = center.clone().add(x, y, z).getBlock();

                    if (block.getType() == Material.AIR) {
                        block.setType(Material.COBWEB, false);
                        AbilityBlockTracker.track(block.getLocation());
                        changed.add(block);
                    }
                }
            }
        }

        if (center.getWorld() != null) {
            center.getWorld().spawnParticle(Particle.CLOUD, center, 60, 1.2, 0.8, 1.2, 0.05);
            center.getWorld().playSound(center, "block.cobweb.place", 1.0F, 0.7F);
        }

        if (changed.isEmpty()) return;

        placedWebs.add(changed);

        new BukkitRunnable() {
            @Override
            public void run() {
                for (Block block : changed) {
                    if (block.getType() == Material.COBWEB) {
                        AbilityBlockTracker.untrack(block.getLocation());
                        block.setType(Material.AIR, false);
                    }
                }
                placedWebs.remove(changed);
            }
        }.runTaskLater(plugin, durationTicks);
    }

    public void clear() {
        for (List<Block> blocks : placedWebs) {
            for (Block block : blocks) {
                if (block.getType() == Material.COBWEB) {
                    AbilityBlockTracker.untrack(block.getLocation());
                    block.setType(Material.AIR, false);
                }
            }
        }
        placedWebs.clear();
    }
}
