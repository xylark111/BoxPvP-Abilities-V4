package com.contoh.boxpvp;

import org.bukkit.Location;

public final class AreaUtil {

    private AreaUtil() {
    }

    public static boolean inside(Location center, double size, boolean sphere, Location loc) {
        if (center.getWorld() == null || !center.getWorld().equals(loc.getWorld())) return false;

        double half = size / 2.0;

        if (sphere) {
            return center.distanceSquared(loc) <= half * half;
        }

        return Math.abs(loc.getX() - center.getX()) <= half
                && Math.abs(loc.getY() - center.getY()) <= half
                && Math.abs(loc.getZ() - center.getZ()) <= half;
    }
}
