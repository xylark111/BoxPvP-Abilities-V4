package com.contoh.boxpvp;

import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public final class AbilityCommand implements CommandExecutor, TabCompleter {

    private final BoxPVPAbilities plugin;

    public AbilityCommand(BoxPVPAbilities plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!sender.hasPermission("boxpvpabilities.give")) {
            sender.sendMessage(BoxPVPAbilities.color(plugin.getMessage("no-permission")));
            return true;
        }

        if (args.length < 2 || !args[0].equalsIgnoreCase("give")) {
            sender.sendMessage(BoxPVPAbilities.color(
                    "&e/ability give <" + String.join("|", AbilityItems.KEYS) + "> [player] [amount]"));
            return true;
        }

        Player target;
        if (args.length >= 3) {
            target = Bukkit.getPlayerExact(args[2]);
            if (target == null) {
                sender.sendMessage(BoxPVPAbilities.color("&cPlayer not found."));
                return true;
            }
        } else if (sender instanceof Player self) {
            target = self;
        } else {
            sender.sendMessage("Console must specify a player: /ability give <ability> <player> [amount]");
            return true;
        }

        int amount = 1;
        if (args.length >= 4) {
            try {
                amount = Math.max(1, Math.min(64, Integer.parseInt(args[3])));
            } catch (NumberFormatException e) {
                sender.sendMessage(BoxPVPAbilities.color("&cInvalid amount."));
                return true;
            }
        }

        ItemStack item = plugin.getAbilityItems().create(args[1].toLowerCase(Locale.ROOT));
        if (item == null) {
            sender.sendMessage(BoxPVPAbilities.color(plugin.getMessage("invalid-item")));
            return true;
        }

        item.setAmount(amount);

        var leftover = target.getInventory().addItem(item);
        for (ItemStack extra : leftover.values()) {
            target.getWorld().dropItemNaturally(target.getLocation(), extra);
        }

        sender.sendMessage(BoxPVPAbilities.color(
                "&aGave &e" + amount + "x " + args[1].toLowerCase(Locale.ROOT) + " &ato &e" + target.getName()));
        return true;
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String label, String[] args) {
        if (args.length == 1) return List.of("give");

        if (args.length == 2) {
            List<String> result = new ArrayList<>();
            for (String key : AbilityItems.KEYS) {
                if (key.startsWith(args[1].toLowerCase(Locale.ROOT))) result.add(key);
            }
            return result;
        }

        if (args.length == 3) return null; // online player names

        return List.of();
    }
}
