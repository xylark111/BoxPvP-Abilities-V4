package com.contoh.boxpvp;

import org.bukkit.Color;
import org.bukkit.Location;
import org.bukkit.Particle;
import org.bukkit.World;

public final class ParticleUtil {

    private ParticleUtil() {
    }

    public static void circle(Location center, double radius, int points, Particle particle, Object data) {
        World world = center.getWorld();
        if (world == null) return;

        for (int i = 0; i < points; i++) {
            double angle = (Math.PI * 2 * i) / points;
            double x = center.getX() + Math.cos(angle) * radius;
            double z = center.getZ() + Math.sin(angle) * radius;

            world.spawnParticle(particle, x, center.getY() + 0.1, z, 1, 0, 0, 0, 0, data);
        }
    }

    public static void sphere(Location center, double radius, int rings, int pointsPerRing,
                              Particle particle, Object data) {
        for (int i = 1; i < rings; i++) {
            double phi = Math.PI * i / rings;
            double y = Math.cos(phi) * radius;
            double ringRadius = Math.sin(phi) * radius;

            circle(center.clone().add(0, y, 0), ringRadius, pointsPerRing, particle, data);
        }
    }

    public static void cubeEdges(Location center, double size, double angle, int pointsPerEdge,
                                 Particle particle, Object data) {
        World world = center.getWorld();
        if (world == null) return;

        double h = size / 2.0;
        double cos = Math.cos(angle);
        double sin = Math.sin(angle);

        for (int axis = 0; axis < 3; axis++) {
            for (int s1 = -1; s1 <= 1; s1 += 2) {
                for (int s2 = -1; s2 <= 1; s2 += 2) {
                    for (int i = 0; i <= pointsPerEdge; i++) {
                        double t = -h + (size * i / pointsPerEdge);
                        double x;
                        double y;
                        double z;

                        if (axis == 0) {
                            x = t;
                            y = s1 * h;
                            z = s2 * h;
                        } else if (axis == 1) {
                            x = s1 * h;
                            y = t;
                            z = s2 * h;
                        } else {
                            x = s1 * h;
                            y = s2 * h;
                            z = t;
                        }

                        double rx = x * cos - z * sin;
                        double rz = x * sin + z * cos;

                        world.spawnParticle(particle,
                                center.getX() + rx, center.getY() + y, center.getZ() + rz,
                                1, 0, 0, 0, 0, data);
                    }
                }
            }
        }
    }

    public static void spiral(Location base, double radius, double height, int points,
                              Particle particle, Object data) {
        World world = base.getWorld();
        if (world == null) return;

        for (int i = 0; i < points; i++) {
            double progress = (double) i / points;
            double angle = Math.PI * 6 * progress;
            double currentRadius = radius * (1 - progress);

            double x = base.getX() + Math.cos(angle) * currentRadius;
            double y = base.getY() + height * progress;
            double z = base.getZ() + Math.sin(angle) * currentRadius;

            world.spawnParticle(particle, x, y, z, 1, 0, 0, 0, 0, data);
        }
    }

    public static Particle.DustOptions dust(String rgbConfig) {
        try {
            String[] parts = rgbConfig.split(",");
            int red = Integer.parseInt(parts[0].trim());
            int green = Integer.parseInt(parts[1].trim());
            int blue = Integer.parseInt(parts[2].trim());
            return new Particle.DustOptions(Color.fromRGB(red, green, blue), 1.5F);
        } catch (Exception e) {
            return new Particle.DustOptions(Color.WHITE, 1.5F);
        }
    }
}
