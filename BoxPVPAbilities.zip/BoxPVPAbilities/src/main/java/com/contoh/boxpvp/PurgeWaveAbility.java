package com.contoh.boxpvp;

import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.block.Block;
import org.bukkit.entity.Player;
import org.bukkit.event.Event;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.scheduler.BukkitRunnable;

import java.util.HashSet;
import java.util.Set;

public final class PurgeWaveAbility implements Listener {

    private final BoxPVPAbilities plugin;
    private final Set<Location> playerPlacedBlocks = new HashSet<>();

    public PurgeWaveAbility(BoxPVPAbilities plugin) {
        this.plugin = plugin;
    }

    @EventHandler(ignoreCancelled = true)
    public void onBlockPlace(BlockPlaceEvent event) {
        playerPlacedBlocks.add(event.getBlockPlaced().getLocation());
    }

    @EventHandler(ignoreCancelled = true)
    public void onBlockBreak(BlockBreakEvent event) {
        playerPlacedBlocks.remove(event.getBlock().getLocation());
    }

    @EventHandler
    public void onRightClick(PlayerInteractEvent event) {
        if (event.getAction() != Action.RIGHT_CLICK_AIR && event.getAction() != Action.RIGHT_CLICK_BLOCK) return;
        if (event.getHand() != EquipmentSlot.HAND) return;
        if (!plugin.getAbilityItems().isAbility(event.getItem(), AbilityItems.PURGE_WAVE)) return;

        event.setUseItemInHand(Event.Result.DENY);
        event.setCancelled(true);

        Player player = event.getPlayer();
        if (!plugin.beginUse(player, AbilityItems.PURGE_WAVE, "Purge Wave", "purge-wave", 80)) return;

        Location center = player.getLocation().clone();
        double radius = plugin.getConfig().getDouble("purge-wave.radius", 7.0);
        double damage = plugin.getConfig().getDouble("purge-wave.damage", 2.0);
        int stunDuration = plugin.getConfig().getInt("purge-wave.stun-duration", 3);

        startWave(center, radius);
        purgeObstacles(center, radius);
        damageAndStun(player, center, radius, damage, stunDuration);
    }

    private void startWave(Location center, double radius) {
        if (center.getWorld() == null) return;

        Particle.DustOptions dust = ParticleUtil.dust(
                plugin.getConfig().getString("purge-wave.colors", "255,255,255"));

        center.getWorld().playSound(center, Sound.ENTITY_GENERIC_EXPLODE, 1.3F, 0.7F);

        new BukkitRunnable() {
            double current = 0.5;

            @Override
            public void run() {
                current += 0.35;

                if (current > radius) {
                    cancel();
                    return;
                }

                ParticleUtil.circle(center, current, 72, Particle.REDSTONE, dust);
                ParticleUtil.circle(center.clone().add(0, 0.5, 0), current * 0.85, 56, Particle.CLOUD, null);
                ParticleUtil.spiral(center, current, 2.5, 50, Particle.FLAME, null);

                center.getWorld().spawnParticle(Particle.EXPLOSION_LARGE, center.clone().add(0, 1, 0),
                        2, current * 0.2, 0.5, current * 0.2, 0);
            }
        }.runTaskTimer(plugin, 0L, 1L);
    }

    private void purgeObstacles(Location center, double radius) {
        for (Location location : new HashSet<>(playerPlacedBlocks)) {
            if (location.getWorld() == null || !location.getWorld().equals(center.getWorld())) continue;
            if (location.distanceSquared(center) > radius * radius) continue;

            Block block = location.getBlock();
            playerPlacedBlocks.remove(location);

            if (block.getType() == Material.AIR) continue;

            block.setType(Material.AIR, false);
            location.getWorld().spawnParticle(Particle.CLOUD, location.clone().add(0.5, 0.5, 0.5),
                    12, 0.1, 0.1, 0.1, 0.05);
        }
    }

    private void damageAndStun(Player owner, Location center, double radius, double damage, int stunDuration) {
        if (center.getWorld() == null) return;

        for (Player target : center.getWorld().getPlayers()) {
            if (target.equals(owner)) continue;
            if (target.getLocation().distanceSquared(center) > radius * radius) continue;

            target.damage(damage, owner);
            plugin.getFreezeManager().freeze(target, stunDuration * 1000L);
            BoxPVPAbilities.actionBar(target, "&f&lPURGED!");
        }
    }

    public void clear() {
        playerPlacedBlocks.clear();
    }
}
