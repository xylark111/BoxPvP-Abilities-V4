package com.contoh.boxpvp;

import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockPlaceEvent;

/** Stops ability items that are placeable blocks (e.g. iron bars) from being placed. */
public final class ItemGuard implements Listener {

    private final BoxPVPAbilities plugin;

    public ItemGuard(BoxPVPAbilities plugin) {
        this.plugin = plugin;
    }

    @EventHandler(ignoreCancelled = true)
    public void onPlace(BlockPlaceEvent event) {
        if (plugin.getAbilityItems().getAbilityId(event.getItemInHand()) != null) {
            event.setCancelled(true);
        }
    }
}
