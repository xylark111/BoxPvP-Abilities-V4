package com.contoh.boxpvp;

import org.bukkit.Location;
import org.bukkit.Particle;
import org.bukkit.entity.Player;
import org.bukkit.event.Event;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.entity.EntityToggleGlideEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.scheduler.BukkitRunnable;

import java.util.HashSet;
import java.util.Locale;
import java.util.Set;
import java.util.UUID;

public final class ElytraZoneAbility implements Listener {

    private final BoxPVPAbilities plugin;
    private final Set<Zone> zones = new HashSet<>();

    public ElytraZoneAbility(BoxPVPAbilities plugin) {
        this.plugin = plugin;
    }

    @EventHandler
    public void onRightClick(PlayerInteractEvent event) {
        if (event.getAction() != Action.RIGHT_CLICK_AIR && event.getAction() != Action.RIGHT_CLICK_BLOCK) return;
        if (event.getHand() != EquipmentSlot.HAND) return;
        if (!plugin.getAbilityItems().isAbility(event.getItem(), AbilityItems.ELYTRA_ZONE)) return;

        event.setUseItemInHand(Event.Result.DENY);
        event.setCancelled(true);

        Player player = event.getPlayer();
        if (!plugin.beginUse(player, AbilityItems.ELYTRA_ZONE, "Elytra Zone", "elytra-zone", 45)) return;

        int duration = plugin.getConfig().getInt("elytra-zone.duration", 12);
        double size = plugin.getConfig().getDouble("elytra-zone.size", 8.0);
        boolean sphere = plugin.getConfig().getString("elytra-zone.shape", "CUBE")
                .toUpperCase(Locale.ROOT).equals("SPHERE");

        Location center = player.getLocation().getBlock().getLocation()
                .add(0.5, size / 2.0 - 1.0, 0.5);

        Zone zone = new Zone(player.getUniqueId(), center, size, sphere,
                System.currentTimeMillis() + duration * 1000L);

        zones.add(zone);
        startTask(zone);
    }

    @EventHandler(ignoreCancelled = true)
    public void onGlide(EntityToggleGlideEvent event) {
        if (!event.isGliding()) return;
        if (!(event.getEntity() instanceof Player player)) return;

        for (Zone zone : zones) {
            if (zone.owner.equals(player.getUniqueId())) continue;

            if (AreaUtil.inside(zone.center, zone.size, zone.sphere, player.getLocation())) {
                event.setCancelled(true);
                return;
            }
        }
    }

    private void startTask(Zone zone) {
        Particle.DustOptions dust = ParticleUtil.dust(
                plugin.getConfig().getString("elytra-zone.colors", "255,40,40"));
        double rotationSpeed = plugin.getConfig().getDouble("elytra-zone.rotation-speed", 0.08);
        double pulseSpeed = plugin.getConfig().getDouble("elytra-zone.pulse-speed", 0.15);

        new BukkitRunnable() {
            double angle = 0;
            double phase = 0;

            @Override
            public void run() {
                if (System.currentTimeMillis() > zone.expire || !zones.contains(zone)) {
                    zones.remove(zone);
                    cancel();
                    return;
                }

                double current = zone.size * (1 + Math.sin(phase) * 0.04);

                if (zone.sphere) {
                    ParticleUtil.sphere(zone.center, current / 2.0, 8, 28, Particle.REDSTONE, dust);
                } else {
                    ParticleUtil.cubeEdges(zone.center, current, angle, 10, Particle.REDSTONE, dust);
                }

                ParticleUtil.spiral(zone.center.clone().add(0, -current / 2.0, 0),
                        current / 2.0, current, 40, Particle.PORTAL, null);

                tickEnemies(zone);

                angle += rotationSpeed;
                phase += pulseSpeed;
            }
        }.runTaskTimer(plugin, 0L, 2L);
    }

    private void tickEnemies(Zone zone) {
        if (zone.center.getWorld() == null) return;

        for (Player target : zone.center.getWorld().getPlayers()) {
            if (target.getUniqueId().equals(zone.owner)) continue;
            if (!AreaUtil.inside(zone.center, zone.size, zone.sphere, target.getLocation())) continue;

            if (target.isGliding()) {
                target.setGliding(false);
            }

            if (zone.affected.add(target.getUniqueId())) {
                plugin.applyConfigEffects(target, "elytra-zone.enemy-effects");
            }
        }
    }

    public void clear() {
        zones.clear();
    }

    private static final class Zone {
        final UUID owner;
        final Location center;
        final double size;
        final boolean sphere;
        final long expire;
        final Set<UUID> affected = new HashSet<>();

        Zone(UUID owner, Location center, double size, boolean sphere, long expire) {
            this.owner = owner;
            this.center = center;
            this.size = size;
            this.sphere = sphere;
            this.expire = expire;
        }
    }
}
