package com.contoh.boxpvp;

import org.bukkit.Location;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.entity.AbstractArrow;
import org.bukkit.entity.ArmorStand;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.entity.Trident;
import org.bukkit.event.Event;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.entity.ProjectileHitEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.metadata.FixedMetadataValue;
import org.bukkit.scheduler.BukkitRunnable;

public final class TridentBlastAbility implements Listener {

    private static final String META = "boxpvp_trident_blast";

    private final BoxPVPAbilities plugin;

    public TridentBlastAbility(BoxPVPAbilities plugin) {
        this.plugin = plugin;
    }

    @EventHandler
    public void onRightClick(PlayerInteractEvent event) {
        if (event.getAction() != Action.RIGHT_CLICK_AIR && event.getAction() != Action.RIGHT_CLICK_BLOCK) return;
        if (event.getHand() != EquipmentSlot.HAND) return;
        if (!plugin.getAbilityItems().isAbility(event.getItem(), AbilityItems.TRIDENT_BLAST)) return;

        event.setUseItemInHand(Event.Result.DENY);
        event.setCancelled(true);

        Player player = event.getPlayer();
        if (!plugin.beginUse(player, AbilityItems.TRIDENT_BLAST, "Trident Blast", "trident-blast", 25)) return;

        Trident trident = player.launchProjectile(Trident.class,
                player.getEyeLocation().getDirection().multiply(2.8));
        trident.setPickupStatus(AbstractArrow.PickupStatus.DISALLOWED);
        trident.setMetadata(META, new FixedMetadataValue(plugin, true));
    }

    @EventHandler
    public void onTridentHit(ProjectileHitEvent event) {
        if (!(event.getEntity() instanceof Trident trident)) return;
        if (!trident.hasMetadata(META)) return;
        if (!(trident.getShooter() instanceof Player attacker)) return;

        trident.removeMetadata(META, plugin);

        explode(trident.getLocation(), attacker);
        trident.remove();
    }

    private void explode(Location center, Player attacker) {
        if (center.getWorld() == null) return;

        double damage = plugin.getConfig().getDouble("trident-blast.damage", 8.0);
        double radius = plugin.getConfig().getDouble("trident-blast.explosion-radius", 4.0);
        Particle.DustOptions dust = ParticleUtil.dust(
                plugin.getConfig().getString("trident-blast.colors", "255,180,40"));

        center.getWorld().spawnParticle(Particle.EXPLOSION_LARGE, center.clone().add(0, 1, 0),
                5, radius * 0.2, radius * 0.2, radius * 0.2, 0);
        center.getWorld().playSound(center, Sound.ENTITY_GENERIC_EXPLODE, 1.2F, 0.9F);

        new BukkitRunnable() {
            double current = 0.5;

            @Override
            public void run() {
                current += 0.45;

                if (current > radius) {
                    cancel();
                    return;
                }

                ParticleUtil.circle(center, current, 48, Particle.FLAME, null);
                ParticleUtil.circle(center, current, 32, Particle.REDSTONE, dust);
            }
        }.runTaskTimer(plugin, 0L, 1L);

        for (LivingEntity target : center.getWorld().getNearbyLivingEntities(center, radius, radius, radius)) {
            if (target.equals(attacker)) continue;
            if (target instanceof ArmorStand) continue;
            if (target.getLocation().distanceSquared(center) > radius * radius) continue;

            target.damage(damage, attacker);
            target.getWorld().spawnParticle(Particle.CRIT, target.getLocation().add(0, 1, 0),
                    25, 0.3, 0.3, 0.3, 0.2);
        }
    }
}
