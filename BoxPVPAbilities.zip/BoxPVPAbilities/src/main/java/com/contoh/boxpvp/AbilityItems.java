package com.contoh.boxpvp;

import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.entity.Player;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;

import java.util.List;
import java.util.Locale;

public final class AbilityItems {

    public static final String ELYTRA_ZONE = "elytra_zone";
    public static final String WEB_TRAP = "web_trap";
    public static final String TRIDENT_BLAST = "trident_blast";
    public static final String TIME_STOP = "time_stop";
    public static final String BOW_STUN = "bow_stun";
    public static final String CAGE_TRAP = "cage_trap";
    public static final String PURGE_WAVE = "purge_wave";

    public static final List<String> KEYS = List.of(
            "elytrazone", "webtrap", "tridentblast", "timestop",
            "bowstun", "cagetrap", "purgewave"
    );

    private final NamespacedKey abilityKey;

    public AbilityItems(BoxPVPAbilities plugin) {
        this.abilityKey = new NamespacedKey(plugin, "ability_id");
    }

    public ItemStack create(String key) {
        switch (key.toLowerCase(Locale.ROOT)) {
            case "elytrazone":
                return build(Material.FEATHER, ELYTRA_ZONE, "&b&lElytra Zone", List.of(
                        "&7Right-click to create a zone.",
                        "&7Enemies inside cannot use Elytra.",
                        "&7You can still use Elytra.",
                        "&7One-time use item."));
            case "webtrap":
                return build(Material.CROSSBOW, WEB_TRAP, "&a&lWeb Trap Crossbow", List.of(
                        "&7Right-click to fire a multishot.",
                        "&7Arrows create a 3x3 cobweb trap.",
                        "&7One-time use item."));
            case "tridentblast":
                return build(Material.TRIDENT, TRIDENT_BLAST, "&6&lTrident Blast", List.of(
                        "&7Right-click to throw the trident.",
                        "&7Creates an area explosion on impact.",
                        "&7One-time use item."));
            case "timestop":
                return build(Material.CLOCK, TIME_STOP, "&5&lTime Stop", List.of(
                        "&7Right-click to stop time.",
                        "&7Enemies inside the zone cannot move.",
                        "&7One-time use item."));
            case "bowstun":
                return build(Material.BOW, BOW_STUN, "&3&lSky Rain Bow", List.of(
                        "&7Right-click to fire without arrows.",
                        "&7Hits stun the target and summon arrow rain.",
                        "&7One-time use item."));
            case "cagetrap":
                return build(Material.IRON_BARS, CAGE_TRAP, "&2&lCage Trap", List.of(
                        "&7Hit an enemy to trap both of you.",
                        "&7Neither player can leave until it opens.",
                        "&7One-time use item."));
            case "purgewave":
                return build(Material.BLAZE_POWDER, PURGE_WAVE, "&f&lPurge Wave", List.of(
                        "&7Right-click to release a shockwave.",
                        "&7Removes player-placed blocks nearby.",
                        "&7Stuns nearby enemies briefly.",
                        "&7One-time use item."));
            default:
                return null;
        }
    }

    private ItemStack build(Material material, String id, String name, List<String> lore) {
        ItemStack item = new ItemStack(material);
        ItemMeta meta = item.getItemMeta();
        if (meta == null) return item;

        meta.setDisplayName(BoxPVPAbilities.color(name));
        meta.setLore(lore.stream().map(BoxPVPAbilities::color).toList());
        meta.setUnbreakable(true);
        meta.getPersistentDataContainer().set(abilityKey, PersistentDataType.STRING, id);

        item.setItemMeta(meta);
        return item;
    }

    public String getAbilityId(ItemStack item) {
        if (item == null || !item.hasItemMeta()) return null;
        ItemMeta meta = item.getItemMeta();
        if (meta == null) return null;
        return meta.getPersistentDataContainer().get(abilityKey, PersistentDataType.STRING);
    }

    public boolean isAbility(ItemStack item, String abilityId) {
        return abilityId.equals(getAbilityId(item));
    }

    public void consumeOne(Player player, EquipmentSlot hand) {
        ItemStack current = hand == EquipmentSlot.OFF_HAND
                ? player.getInventory().getItemInOffHand()
                : player.getInventory().getItemInMainHand();

        ItemStack replacement;
        if (current.getAmount() <= 1) {
            replacement = new ItemStack(Material.AIR);
        } else {
            replacement = current.clone();
            replacement.setAmount(current.getAmount() - 1);
        }

        if (hand == EquipmentSlot.OFF_HAND) {
            player.getInventory().setItemInOffHand(replacement);
        } else {
            player.getInventory().setItemInMainHand(replacement);
        }

        player.updateInventory();
    }
}
