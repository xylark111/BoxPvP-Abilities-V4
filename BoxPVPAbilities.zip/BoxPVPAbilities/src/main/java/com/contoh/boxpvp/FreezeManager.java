package com.contoh.boxpvp;

import org.bukkit.Location;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerMoveEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.event.player.PlayerTeleportEvent;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/** Shared freeze/stun handling used by Time Stop, Sky Rain Bow and Purge Wave. */
public final class FreezeManager implements Listener {

    private final Map<UUID, Long> frozen = new HashMap<>();

    public void freeze(Player player, long millis) {
        frozen.put(player.getUniqueId(), System.currentTimeMillis() + millis);
    }

    public boolean isFrozen(UUID uuid) {
        Long expire = frozen.get(uuid);
        if (expire == null) return false;

        if (System.currentTimeMillis() > expire) {
            frozen.remove(uuid);
            return false;
        }
        return true;
    }

    @EventHandler
    public void onMove(PlayerMoveEvent event) {
        if (!isFrozen(event.getPlayer().getUniqueId())) return;

        Location from = event.getFrom();
        Location to = event.getTo();
        if (to == null) return;

        if (from.getX() == to.getX() && from.getY() == to.getY() && from.getZ() == to.getZ()) {
            return; // only looking around
        }

        Location locked = from.clone();
        locked.setYaw(to.getYaw());
        locked.setPitch(to.getPitch());
        event.setTo(locked);
    }

    @EventHandler
    public void onTeleport(PlayerTeleportEvent event) {
        if (isFrozen(event.getPlayer().getUniqueId())) {
            event.setCancelled(true);
        }
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent event) {
        frozen.remove(event.getPlayer().getUniqueId());
    }

    public void clear() {
        frozen.clear();
    }
}
