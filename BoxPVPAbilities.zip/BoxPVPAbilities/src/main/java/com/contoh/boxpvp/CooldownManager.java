package com.contoh.boxpvp;

import org.bukkit.Bukkit;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitRunnable;

import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;

public final class CooldownManager {

    private final Map<UUID, Map<String, Long>> cooldowns = new HashMap<>();

    public boolean isOnCooldown(Player player, String ability) {
        return getRemainingSeconds(player.getUniqueId(), ability) > 0;
    }

    public long getRemainingSeconds(UUID uuid, String ability) {
        Map<String, Long> map = cooldowns.get(uuid);
        if (map == null) return 0;

        Long expire = map.get(ability);
        if (expire == null) return 0;

        long millis = expire - System.currentTimeMillis();
        return millis <= 0 ? 0 : (millis + 999) / 1000;
    }

    public void start(BoxPVPAbilities plugin, Player player, String ability,
                      String displayName, int seconds, String configKey) {
        UUID uuid = player.getUniqueId();

        cooldowns.computeIfAbsent(uuid, key -> new HashMap<>())
                .put(ability, System.currentTimeMillis() + (seconds * 1000L));

        String soundName = plugin.getConfig().getString("sounds." + configKey, "ENTITY_PLAYER_LEVELUP");
        try {
            player.playSound(player.getLocation(),
                    Sound.valueOf(soundName.toUpperCase(Locale.ROOT)), 1.0F, 1.0F);
        } catch (IllegalArgumentException ignored) {
        }

        new BukkitRunnable() {
            @Override
            public void run() {
                Player online = Bukkit.getPlayer(uuid);
                if (online == null) {
                    cancel();
                    return;
                }

                long left = getRemainingSeconds(uuid, ability);
                if (left <= 0) {
                    BoxPVPAbilities.actionBar(online, "&a&l" + displayName + " &ais ready to use!");
                    cancel();
                    return;
                }

                BoxPVPAbilities.actionBar(online, "&c&l" + displayName + " &7cooldown: &e" + left + "s");
            }
        }.runTaskTimer(plugin, 0L, 20L);
    }

    public void clear() {
        cooldowns.clear();
    }
}
