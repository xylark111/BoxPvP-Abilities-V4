package com.contoh.boxpvp;

import net.md_5.bungee.api.ChatMessageType;
import net.md_5.bungee.api.chat.TextComponent;
import org.bukkit.ChatColor;
import org.bukkit.NamespacedKey;
import org.bukkit.command.PluginCommand;
import org.bukkit.entity.Player;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;

import java.util.Locale;

public final class BoxPVPAbilities extends JavaPlugin {

    private AbilityItems abilityItems;
    private CooldownManager cooldownManager;
    private FreezeManager freezeManager;

    private ElytraZoneAbility elytraZone;
    private WebTrapAbility webTrap;
    private TridentBlastAbility tridentBlast;
    private TimeStopAbility timeStop;
    private BowStunAbility bowStun;
    private CageTrapAbility cageTrap;
    private PurgeWaveAbility purgeWave;

    @Override
    public void onEnable() {
        saveDefaultConfig();

        abilityItems = new AbilityItems(this);
        cooldownManager = new CooldownManager();
        freezeManager = new FreezeManager();

        elytraZone = new ElytraZoneAbility(this);
        webTrap = new WebTrapAbility(this);
        tridentBlast = new TridentBlastAbility(this);
        timeStop = new TimeStopAbility(this);
        bowStun = new BowStunAbility(this);
        cageTrap = new CageTrapAbility(this);
        purgeWave = new PurgeWaveAbility(this);

        var pm = getServer().getPluginManager();
        pm.registerEvents(freezeManager, this);
        pm.registerEvents(new ItemGuard(this), this);
        pm.registerEvents(elytraZone, this);
        pm.registerEvents(webTrap, this);
        pm.registerEvents(tridentBlast, this);
        pm.registerEvents(timeStop, this);
        pm.registerEvents(bowStun, this);
        pm.registerEvents(cageTrap, this);
        pm.registerEvents(purgeWave, this);

        PluginCommand command = getCommand("ability");
        if (command != null) {
            AbilityCommand executor = new AbilityCommand(this);
            command.setExecutor(executor);
            command.setTabCompleter(executor);
        }

        getLogger().info("BoxPVPAbilities v4 enabled.");
    }

    @Override
    public void onDisable() {
        if (elytraZone != null) elytraZone.clear();
        if (webTrap != null) webTrap.clear();
        if (cageTrap != null) cageTrap.clear();
        if (purgeWave != null) purgeWave.clear();
        if (freezeManager != null) freezeManager.clear();
        if (cooldownManager != null) cooldownManager.clear();
    }

    /**
     * Shared start-of-use logic: checks cooldown, consumes one item,
     * starts the cooldown and sends the activation message.
     */
    public boolean beginUse(Player player, String abilityId, String display,
                            String configKey, int defaultCooldown) {
        if (cooldownManager.isOnCooldown(player, abilityId)) {
            long seconds = cooldownManager.getRemainingSeconds(player.getUniqueId(), abilityId);
            player.sendMessage(color(getMessage("cooldown")
                    .replace("{ability}", display)
                    .replace("{seconds}", String.valueOf(seconds))));
            return false;
        }

        abilityItems.consumeOne(player, EquipmentSlot.HAND);

        int cooldown = getConfig().getInt(configKey + ".cooldown", defaultCooldown);
        cooldownManager.start(this, player, abilityId, display, cooldown, configKey);

        player.sendMessage(color(getMessage("activated").replace("{ability}", display)));
        return true;
    }

    /** Applies effects from a config list formatted as "EFFECT:seconds:amplifier". */
    public void applyConfigEffects(Player target, String path) {
        for (String line : getConfig().getStringList(path)) {
            String[] parts = line.split(":");
            if (parts.length < 3) continue;

            try {
                String name = parts[0].trim().toLowerCase(Locale.ROOT);

                PotionEffectType type = PotionEffectType.getByKey(NamespacedKey.minecraft(name));
                if (type == null) type = PotionEffectType.getByName(name.toUpperCase(Locale.ROOT));
                if (type == null) continue;

                int seconds = Integer.parseInt(parts[1].trim());
                int amplifier = Integer.parseInt(parts[2].trim());

                target.addPotionEffect(new PotionEffect(type, seconds * 20, amplifier, false, true, true));
            } catch (Exception ignored) {
            }
        }
    }

    public String getMessage(String key) {
        return getConfig().getString("messages." + key, "");
    }

    public AbilityItems getAbilityItems() {
        return abilityItems;
    }

    public CooldownManager getCooldownManager() {
        return cooldownManager;
    }

    public FreezeManager getFreezeManager() {
        return freezeManager;
    }

    public static String color(String input) {
        return ChatColor.translateAlternateColorCodes('&', input == null ? "" : input);
    }

    public static void actionBar(Player player, String message) {
        player.spigot().sendMessage(ChatMessageType.ACTION_BAR, new TextComponent(color(message)));
    }
}
