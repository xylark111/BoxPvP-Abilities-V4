package com.contoh.boxpvp;

import org.bukkit.Location;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.event.Event;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.scheduler.BukkitRunnable;

import java.util.Locale;

public final class TimeStopAbility implements Listener {

    private final BoxPVPAbilities plugin;

    public TimeStopAbility(BoxPVPAbilities plugin) {
        this.plugin = plugin;
    }

    @EventHandler
    public void onRightClick(PlayerInteractEvent event) {
        if (event.getAction() != Action.RIGHT_CLICK_AIR && event.getAction() != Action.RIGHT_CLICK_BLOCK) return;
        if (event.getHand() != EquipmentSlot.HAND) return;
        if (!plugin.getAbilityItems().isAbility(event.getItem(), AbilityItems.TIME_STOP)) return;

        event.setUseItemInHand(Event.Result.DENY);
        event.setCancelled(true);

        Player player = event.getPlayer();
        if (!plugin.beginUse(player, AbilityItems.TIME_STOP, "Time Stop", "time-stop", 90)) return;

        int expandTime = plugin.getConfig().getInt("time-stop.expand-time", 3);
        int freezeDuration = plugin.getConfig().getInt("time-stop.freeze-duration", 6);
        double size = plugin.getConfig().getDouble("time-stop.size", 10.0);
        boolean sphere = plugin.getConfig().getString("time-stop.shape", "CUBE")
                .toUpperCase(Locale.ROOT).equals("SPHERE");

        Location center = player.getLocation().getBlock().getLocation()
                .add(0.5, size / 2.0 - 1.0, 0.5);

        freezeEnemies(player, center, size, sphere, freezeDuration);
        startVisual(center, size, sphere, expandTime, freezeDuration);
    }

    private void freezeEnemies(Player owner, Location center, double size, boolean sphere, int freezeDuration) {
        if (center.getWorld() == null) return;

        for (Player target : center.getWorld().getPlayers()) {
            if (target.equals(owner)) continue;
            if (!AreaUtil.inside(center, size, sphere, target.getLocation())) continue;

            plugin.getFreezeManager().freeze(target, freezeDuration * 1000L);
            plugin.applyConfigEffects(target, "time-stop.enemy-effects");
            BoxPVPAbilities.actionBar(target, "&5&lTIME HAS STOPPED!");
        }
    }

    private void startVisual(Location center, double size, boolean sphere, int expandTime, int freezeDuration) {
        if (center.getWorld() == null) return;

        Particle.DustOptions dust = ParticleUtil.dust(
                plugin.getConfig().getString("time-stop.colors", "160,60,255"));
        double rotationSpeed = plugin.getConfig().getDouble("time-stop.rotation-speed", 0.10);
        double pulseSpeed = plugin.getConfig().getDouble("time-stop.pulse-speed", 0.20);

        long expandTicks = Math.max(1, expandTime * 20L);
        long freezeTicks = Math.max(1, freezeDuration * 20L);
        long totalTicks = expandTicks + freezeTicks;

        center.getWorld().playSound(center, Sound.BLOCK_BEACON_ACTIVATE, 1.5F, 0.5F);
        AbilityMusic.play(plugin, "time-stop", center, totalTicks);

        new BukkitRunnable() {
            long tick = 0;
            double angle = 0;
            double phase = 0;

            @Override
            public void run() {
                if (tick >= totalTicks) {
                    cancel();
                    return;
                }

                double expand = Math.min(1.0, tick / (double) expandTicks);
                double shrink = tick > expandTicks
                        ? Math.max(0.0, 1.0 - (tick - expandTicks) / (double) freezeTicks)
                        : 1.0;

                double current = size * expand * shrink * (1 + Math.sin(phase) * 0.05);

                if (current > 0.2) {
                    if (sphere) {
                        ParticleUtil.sphere(center, current / 2.0, 8, 28, Particle.REDSTONE, dust);
                    } else {
                        ParticleUtil.cubeEdges(center, current, angle, 10, Particle.REDSTONE, dust);
                    }

                    ParticleUtil.spiral(center.clone().add(0, -current / 2.0, 0),
                            current / 2.0, current, 40, Particle.PORTAL, null);

                    center.getWorld().spawnParticle(Particle.SPELL_WITCH, center,
                            20, current * 0.2, current * 0.2, current * 0.2, 0.05);
                }

                angle += rotationSpeed;
                phase += pulseSpeed;
                tick++;
            }
        }.runTaskTimer(plugin, 0L, 1L);
    }
}
