package com.contoh.boxpvp;

import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.block.Block;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.scheduler.BukkitRunnable;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public final class CageTrapAbility implements Listener {

    private final BoxPVPAbilities plugin;
    private final List<List<Block>> cages = new ArrayList<>();

    public CageTrapAbility(BoxPVPAbilities plugin) {
        this.plugin = plugin;
    }

    @EventHandler
    public void onHitEnemy(EntityDamageByEntityEvent event) {
        if (!(event.getDamager() instanceof Player attacker)) return;
        if (!(event.getEntity() instanceof Player victim)) return;

        ItemStack item = attacker.getInventory().getItemInMainHand();
        if (!plugin.getAbilityItems().isAbility(item, AbilityItems.CAGE_TRAP)) return;

        event.setCancelled(true);

        if (!plugin.beginUse(attacker, AbilityItems.CAGE_TRAP, "Cage Trap", "cage-trap", 75)) return;

        createCage(attacker, victim);
        victim.sendMessage(BoxPVPAbilities.color(plugin.getMessage("caged")));
    }

    private void createCage(Player attacker, Player victim) {
        Location mid = attacker.getLocation().clone().add(victim.getLocation()).multiply(0.5);
        Location base = mid.getBlock().getLocation();

        int size = plugin.getConfig().getInt("cage-trap.cage-size", 5);
        int half = Math.max(1, size / 2);
        int durationTicks = plugin.getConfig().getInt("cage-trap.cage-duration", 10) * 20;

        Material parsed = Material.matchMaterial(plugin.getConfig().getString("cage-trap.block", "GLASS"));
        final Material material = (parsed != null && parsed.isBlock()) ? parsed : Material.GLASS;

        Particle.DustOptions dust = ParticleUtil.dust(
                plugin.getConfig().getString("cage-trap.colors", "80,255,180"));

        // Never place blocks inside the two players.
        Set<Block> protectedBlocks = new HashSet<>();
        for (Player p : new Player[]{attacker, victim}) {
            protectedBlocks.add(p.getLocation().getBlock());
            protectedBlocks.add(p.getLocation().clone().add(0, 1, 0).getBlock());
        }

        List<Block> changed = new ArrayList<>();

        for (int x = -half; x <= half; x++) {
            for (int y = -1; y <= half; y++) {
                for (int z = -half; z <= half; z++) {
                    boolean shell = Math.abs(x) == half || Math.abs(z) == half || y == half || y == -1;
                    if (!shell) continue;

                    Block block = base.clone().add(x, y, z).getBlock();

                    if (block.getType() == Material.AIR && !protectedBlocks.contains(block)) {
                        block.setType(material, false);
                        changed.add(block);
                    }
                }
            }
        }

        cages.add(changed);

        Location effect = base.clone().add(0.5, 1, 0.5);
        if (effect.getWorld() != null) {
            effect.getWorld().spawnParticle(Particle.PORTAL, effect, 120, half * 0.5, 1.5, half * 0.5, 0.15);
            effect.getWorld().spawnParticle(Particle.REDSTONE, effect, 80, half * 0.5, 1.5, half * 0.5, 0, dust);
            effect.getWorld().playSound(effect, Sound.BLOCK_GLASS_PLACE, 1.2F, 0.6F);
        }

        new BukkitRunnable() {
            @Override
            public void run() {
                for (Block block : changed) {
                    if (block.getType() == material) {
                        block.setType(Material.AIR, false);
                    }
                }
                cages.remove(changed);
            }
        }.runTaskLater(plugin, durationTicks);
    }

    public void clear() {
        for (List<Block> blocks : cages) {
            for (Block block : blocks) {
                if (block.getType() != Material.AIR) {
                    block.setType(Material.AIR, false);
                }
            }
        }
        cages.clear();
    }
}
