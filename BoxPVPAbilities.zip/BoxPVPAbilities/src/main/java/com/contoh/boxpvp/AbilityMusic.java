package com.contoh.boxpvp;

import org.bukkit.Location;
import org.bukkit.Sound;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitRunnable;

import java.util.List;
import java.util.Locale;
import java.util.function.Supplier;

/**
 * Plays a looping melody (note-block sounds) or a music disc while an ability runs.
 * Configured under "music.<ability-key>" in config.yml.
 */
public final class AbilityMusic {

    private static final double[] DEFAULT_NOTES = {1.0, 1.26, 1.498, 2.0, 1.498, 1.26};

    private AbilityMusic() {
    }

    public static void play(BoxPVPAbilities plugin, String key, Location location, long durationTicks) {
        Location fixed = location.clone();
        play(plugin, key, () -> fixed, durationTicks);
    }

    public static void play(BoxPVPAbilities plugin, String key, Supplier<Location> source, long durationTicks) {
        ConfigurationSection section = plugin.getConfig().getConfigurationSection("music." + key);
        if (section == null || !section.getBoolean("enabled", true)) return;

        String mainName = section.getString("sound", "BLOCK_NOTE_BLOCK_PLING");
        final Sound main = parse(mainName, Sound.BLOCK_NOTE_BLOCK_PLING);
        final Sound bass = parse(section.getString("bass-sound", ""), null);
        final boolean disc = mainName.toUpperCase(Locale.ROOT).startsWith("MUSIC_DISC");
        final int interval = Math.max(1, section.getInt("interval", 5));
        final float volume = (float) section.getDouble("volume", 0.8);

        List<Double> configured = section.getDoubleList("notes");
        final double[] notes;
        if (configured.isEmpty()) {
            notes = DEFAULT_NOTES;
        } else {
            notes = new double[configured.size()];
            for (int i = 0; i < notes.length; i++) notes[i] = configured.get(i);
        }

        new BukkitRunnable() {
            long tick = 0;
            int index = 0;
            Location last = null;

            @Override
            public void run() {
                Location loc = source.get();

                if (loc == null || loc.getWorld() == null || tick >= durationTicks) {
                    if (disc && last != null && last.getWorld() != null) {
                        for (Player p : last.getWorld().getPlayers()) {
                            p.stopSound(main);
                        }
                    }
                    cancel();
                    return;
                }

                last = loc.clone();

                if (disc) {
                    if (tick == 0) loc.getWorld().playSound(loc, main, volume, 1.0F);
                } else if (tick % interval == 0) {
                    float pitch = (float) Math.max(0.5, Math.min(2.0, notes[index % notes.length]));
                    loc.getWorld().playSound(loc, main, volume, pitch);

                    if (bass != null && index % 4 == 0) {
                        loc.getWorld().playSound(loc, bass, volume, 0.6F);
                    }
                    index++;
                }

                tick++;
            }
        }.runTaskTimer(plugin, 0L, 1L);
    }

    private static Sound parse(String name, Sound fallback) {
        if (name == null || name.isBlank()) return fallback;
        try {
            return Sound.valueOf(name.trim().toUpperCase(Locale.ROOT));
        } catch (IllegalArgumentException e) {
            return fallback;
        }
    }
}
