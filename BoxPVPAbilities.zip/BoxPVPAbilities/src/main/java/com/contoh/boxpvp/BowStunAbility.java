package com.contoh.boxpvp;

import org.bukkit.Location;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.entity.AbstractArrow;
import org.bukkit.entity.Arrow;
import org.bukkit.entity.Player;
import org.bukkit.event.Event;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.entity.ProjectileHitEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.metadata.FixedMetadataValue;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.util.Vector;

/**
 * Sky Rain Bow: the arrow stuns the enemy, the shooter is launched into the sky and
 * fires a barrage of arrows upward (Miya style), which then rain down on the stunned enemy.
 */
public final class BowStunAbility implements Listener {

    private static final String META = "boxpvp_bow_stun";

    private final BoxPVPAbilities plugin;

    public BowStunAbility(BoxPVPAbilities plugin) {
        this.plugin = plugin;
    }

    @EventHandler
    public void onRightClick(PlayerInteractEvent event) {
        if (event.getAction() != Action.RIGHT_CLICK_AIR && event.getAction() != Action.RIGHT_CLICK_BLOCK) return;
        if (event.getHand() != EquipmentSlot.HAND) return;
        if (!plugin.getAbilityItems().isAbility(event.getItem(), AbilityItems.BOW_STUN)) return;

        event.setUseItemInHand(Event.Result.DENY);
        event.setCancelled(true);

        Player player = event.getPlayer();
        if (!plugin.beginUse(player, AbilityItems.BOW_STUN, "Sky Rain Bow", "bow-stun", 60)) return;

        Arrow arrow = player.launchProjectile(Arrow.class,
                player.getEyeLocation().getDirection().multiply(3.0));
        arrow.setPickupStatus(AbstractArrow.PickupStatus.DISALLOWED);
        arrow.setMetadata(META, new FixedMetadataValue(plugin, true));

        player.getWorld().playSound(player.getLocation(), Sound.ENTITY_ARROW_SHOOT, 1.0F, 0.8F);
        player.getWorld().spawnParticle(Particle.ENCHANTMENT_TABLE,
                player.getEyeLocation(), 50, 0.3, 0.3, 0.3, 1.0);
    }

    @EventHandler
    public void onArrowHit(ProjectileHitEvent event) {
        if (!(event.getEntity() instanceof Arrow arrow)) return;
        if (!arrow.hasMetadata(META)) return;

        arrow.removeMetadata(META, plugin);

        if (!(event.getHitEntity() instanceof Player target)) return;
        if (!(arrow.getShooter() instanceof Player attacker)) return;
        if (target.equals(attacker)) return;

        stunTarget(attacker, target);
    }

    private void stunTarget(Player attacker, Player target) {
        int stunSeconds = plugin.getConfig().getInt("bow-stun.stun-duration", 5);
        double riseSpeed = plugin.getConfig().getDouble("bow-stun.rise-speed", 0.55);
        int riseTicks = plugin.getConfig().getInt("bow-stun.rise-ticks", 30);
        int shootCount = plugin.getConfig().getInt("bow-stun.shoot-count", 30);
        int shootInterval = Math.max(1, plugin.getConfig().getInt("bow-stun.shoot-interval", 2));
        int flightTicks = Math.max(1, plugin.getConfig().getInt("bow-stun.flight-ticks", 12));
        double arrowDamage = plugin.getConfig().getDouble("bow-stun.arrow-damage", 1.0);

        Particle.DustOptions dust = ParticleUtil.dust(
                plugin.getConfig().getString("bow-stun.colors", "80,200,255"));

        // Stun the target.
        plugin.getFreezeManager().freeze(target, stunSeconds * 1000L);
        BoxPVPAbilities.actionBar(target, "&3&lYOU ARE STUNNED!");
        target.getWorld().playSound(target.getLocation(), Sound.ENTITY_PLAYER_HURT_FREEZE, 1.2F, 0.7F);

        // Launch the shooter into the sky; slow falling prevents fall damage afterwards.
        long showTicks = riseTicks + (long) shootCount * shootInterval + flightTicks + 20;
        attacker.addPotionEffect(new PotionEffect(PotionEffectType.SLOW_FALLING,
                (int) showTicks + 120, 0, false, false, true));
        BoxPVPAbilities.actionBar(attacker, "&3&lSKY RAIN!");
        attacker.getWorld().playSound(attacker.getLocation(), Sound.ENTITY_FIREWORK_ROCKET_LAUNCH, 1.2F, 1.0F);

        AbilityMusic.play(plugin, "bow-stun",
                () -> attacker.isOnline() ? attacker.getLocation() : null, showTicks);

        startRise(attacker, riseSpeed, riseTicks, dust);
        startShooting(attacker, target, shootCount, shootInterval, flightTicks, arrowDamage, dust);
    }

    private void startRise(Player attacker, double riseSpeed, int riseTicks, Particle.DustOptions dust) {
        new BukkitRunnable() {
            int ticks = 0;

            @Override
            public void run() {
                if (ticks >= riseTicks || !attacker.isOnline() || attacker.isDead()) {
                    cancel();
                    return;
                }

                Vector velocity = attacker.getVelocity();
                velocity.setY(riseSpeed);
                attacker.setVelocity(velocity);
                attacker.setFallDistance(0F);

                attacker.getWorld().spawnParticle(Particle.REDSTONE,
                        attacker.getLocation(), 8, 0.3, 0.1, 0.3, 0, dust);
                attacker.getWorld().spawnParticle(Particle.CLOUD,
                        attacker.getLocation(), 3, 0.2, 0.05, 0.2, 0.02);

                ticks++;
            }
        }.runTaskTimer(plugin, 0L, 1L);
    }

    private void startShooting(Player attacker, Player target, int shootCount, int shootInterval,
                               int flightTicks, double arrowDamage, Particle.DustOptions dust) {
        new BukkitRunnable() {
            int shot = 0;

            @Override
            public void run() {
                if (shot >= shootCount || !attacker.isOnline() || attacker.isDead()) {
                    cancel();
                    return;
                }

                Vector velocity = new Vector(
                        (Math.random() - 0.5) * 0.5,
                        2.0 + Math.random() * 0.6,
                        (Math.random() - 0.5) * 0.5);

                Arrow sky = attacker.launchProjectile(Arrow.class, velocity);
                sky.setPickupStatus(AbstractArrow.PickupStatus.DISALLOWED);

                Location eye = attacker.getEyeLocation();
                attacker.getWorld().playSound(eye, Sound.ENTITY_ARROW_SHOOT, 0.8F,
                        (float) (1.2 + Math.random() * 0.5));
                attacker.getWorld().spawnParticle(Particle.ENCHANTMENT_TABLE, eye, 12, 0.3, 0.3, 0.3, 1.0);
                attacker.getWorld().spawnParticle(Particle.REDSTONE, eye, 8, 0.3, 0.3, 0.3, 0, dust);

                scheduleDrop(sky, attacker, target, flightTicks, arrowDamage, dust);
                shot++;
            }
        }.runTaskTimer(plugin, 4L, shootInterval);
    }

    /** After the arrow has flown up, replace it with an arrow falling onto the stunned target. */
    private void scheduleDrop(Arrow sky, Player attacker, Player target, int flightTicks,
                              double arrowDamage, Particle.DustOptions dust) {
        new BukkitRunnable() {
            @Override
            public void run() {
                if (sky.isValid()) sky.remove();

                if (!target.isOnline() || target.isDead()) return;

                Location drop = target.getLocation().clone().add(
                        (Math.random() - 0.5) * 3,
                        15 + Math.random() * 5,
                        (Math.random() - 0.5) * 3);

                Arrow rain = target.getWorld().spawn(drop, Arrow.class);
                if (attacker.isOnline()) rain.setShooter(attacker);
                rain.setDamage(arrowDamage);
                rain.setPickupStatus(AbstractArrow.PickupStatus.DISALLOWED);
                rain.setVelocity(new Vector(0, -2.0, 0));

                target.getWorld().spawnParticle(Particle.REDSTONE, drop, 10, 0.1, 0.1, 0.1, 0, dust);
            }
        }.runTaskLater(plugin, flightTicks);
    }
}
