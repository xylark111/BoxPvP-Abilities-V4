package com.contoh.boxpvp;

import org.bukkit.Location;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.entity.AbstractArrow;
import org.bukkit.entity.Arrow;
import org.bukkit.entity.Player;
import org.bukkit.event.Event;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.entity.ProjectileHitEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.metadata.FixedMetadataValue;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.util.Vector;

public final class BowStunAbility implements Listener {

    private static final String META = "boxpvp_bow_stun";

    private final BoxPVPAbilities plugin;

    public BowStunAbility(BoxPVPAbilities plugin) {
        this.plugin = plugin;
    }

    @EventHandler
    public void onRightClick(PlayerInteractEvent event) {
        if (event.getAction() != Action.RIGHT_CLICK_AIR && event.getAction() != Action.RIGHT_CLICK_BLOCK) return;
        if (event.getHand() != EquipmentSlot.HAND) return;
        if (!plugin.getAbilityItems().isAbility(event.getItem(), AbilityItems.BOW_STUN)) return;

        event.setUseItemInHand(Event.Result.DENY);
        event.setCancelled(true);

        Player player = event.getPlayer();
        if (!plugin.beginUse(player, AbilityItems.BOW_STUN, "Sky Rain Bow", "bow-stun", 60)) return;

        Arrow arrow = player.launchProjectile(Arrow.class,
                player.getEyeLocation().getDirection().multiply(3.0));
        arrow.setPickupStatus(AbstractArrow.PickupStatus.DISALLOWED);
        arrow.setMetadata(META, new FixedMetadataValue(plugin, true));

        player.getWorld().playSound(player.getLocation(), Sound.ENTITY_ARROW_SHOOT, 1.0F, 0.8F);
        player.getWorld().spawnParticle(Particle.ENCHANTMENT_TABLE,
                player.getEyeLocation(), 50, 0.3, 0.3, 0.3, 1.0);
    }

    @EventHandler
    public void onArrowHit(ProjectileHitEvent event) {
        if (!(event.getEntity() instanceof Arrow arrow)) return;
        if (!arrow.hasMetadata(META)) return;

        arrow.removeMetadata(META, plugin);

        if (!(event.getHitEntity() instanceof Player target)) return;
        if (!(arrow.getShooter() instanceof Player attacker)) return;
        if (target.equals(attacker)) return;

        stunTarget(attacker, target);
    }

    private void stunTarget(Player attacker, Player target) {
        int duration = plugin.getConfig().getInt("bow-stun.stun-duration", 4);
        int arrowCount = plugin.getConfig().getInt("bow-stun.arrow-rain-count", 30);
        double arrowDamage = plugin.getConfig().getDouble("bow-stun.arrow-damage", 3.0);
        Particle.DustOptions dust = ParticleUtil.dust(
                plugin.getConfig().getString("bow-stun.colors", "80,200,255"));

        plugin.getFreezeManager().freeze(target, duration * 1000L);
        BoxPVPAbilities.actionBar(target, "&3&lYOU ARE STUNNED!");
        target.getWorld().playSound(target.getLocation(), Sound.ENTITY_PLAYER_HURT_FREEZE, 1.2F, 0.7F);

        attacker.getWorld().spawnParticle(Particle.ENCHANTMENT_TABLE,
                attacker.getLocation().add(0, 1.5, 0), 60, 0.4, 0.4, 0.4, 1.2);

        new BukkitRunnable() {
            int fired = 0;

            @Override
            public void run() {
                if (fired >= arrowCount
                        || !target.isOnline()
                        || target.isDead()
                        || !plugin.getFreezeManager().isFrozen(target.getUniqueId())) {
                    cancel();
                    return;
                }

                Location spawn = target.getLocation().clone().add(
                        (Math.random() - 0.5) * 3,
                        14 + Math.random() * 4,
                        (Math.random() - 0.5) * 3);

                Arrow rain = target.getWorld().spawn(spawn, Arrow.class);
                rain.setShooter(attacker);
                rain.setDamage(arrowDamage);
                rain.setPickupStatus(AbstractArrow.PickupStatus.DISALLOWED);
                rain.setVelocity(new Vector(0, -2.0, 0));

                target.getWorld().spawnParticle(Particle.REDSTONE, spawn, 10, 0.1, 0.1, 0.1, 0, dust);

                fired++;
            }
        }.runTaskTimer(plugin, 10L, 3L);
    }
}
