package com.contoh.boxpvp;

import org.bukkit.Location;

import java.util.HashSet;
import java.util.Set;

/** Remembers blocks created by abilities (cobwebs, cage) so Purge Wave can remove them. */
public final class AbilityBlockTracker {

    private static final Set<Location> BLOCKS = new HashSet<>();

    private AbilityBlockTracker() {
    }

    public static void track(Location location) {
        BLOCKS.add(location);
    }

    public static void untrack(Location location) {
        BLOCKS.remove(location);
    }

    public static Set<Location> getBlocks() {
        return new HashSet<>(BLOCKS);
    }

    public static void clear() {
        BLOCKS.clear();
    }
}
